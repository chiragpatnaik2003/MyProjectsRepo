using UnityEngine;

public class CanvasManager : MonoBehaviour
{
    public void HideCanvas()
    {
        gameObject.SetActive(false);
    }
}
